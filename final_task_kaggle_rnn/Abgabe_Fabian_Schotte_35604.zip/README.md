# Hinweise zur Abgabe
Da die maximale Größe der möglichen Größe der Datei für den Upload auf Moodle 200MB beträgt, kann ich keine .keras-Modelle mit hochladen.